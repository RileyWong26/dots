return {}
-- this is the old way of making styled inputs
-- using snacks instead
-- return {
--   "stevearc/dressing.nvim",
--   event = "VeryLazy",
-- }
