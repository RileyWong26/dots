return {
  "windwp/nvim-ts-autotag",
  opts = {},
}
