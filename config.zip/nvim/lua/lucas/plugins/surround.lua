-- for ys and ds
return {
  "kylechui/nvim-surround",
  version = "*",
  config = true,
}
